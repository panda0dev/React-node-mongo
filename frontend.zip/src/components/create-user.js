import React, { Component } from "react";
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button';
import axios from 'axios';
export default class CreateUser extends Component {
  constructor(props) {
    super(props)
    // Setting up functions
    this.onChangeUserName = this.onChangeUserName.bind(this);
    this.onChangeUserPassword = this.onChangeUserPassword.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    // Setting up state
    this.state = {
      userId: '',
      password: '',
    }
  }
  onChangeUserName(e) {
    this.setState({ userId: e.target.value })
  }
  onChangeUserPassword(e) {
    this.setState({ password: e.target.value })
  }
  onSubmit(e) {
    e.preventDefault()
    const UserObject = {    
      userId: this.state.userId,
      password: this.state.password,
    };
    axios.post('http://localhost:8888/Users/create-User', UserObject)
      .then(res => console.log(res.data));
    this.setState({ userId: '', password: '' })
  }
  render() {
    return (<div className="form-wrapper">
      <Form onSubmit={this.onSubmit}>
        <Form.Group controlId="Name">
          <Form.Label>UserID</Form.Label>
          <Form.Control type="text" value={this.state.userId} onChange={this.onChangeUserName} />
        </Form.Group>
        <Form.Group controlId="Name">
          <Form.Label>Password</Form.Label>
          <Form.Control type="password" value={this.state.password} onChange={this.onChangeUserPassword} />
        </Form.Group>
        <Button variant="danger" size="lg" block="block" type="submit" className="mt-4">
          Create User
        </Button>
      </Form>
    </div>);
  }
}