let mongoose = require('mongoose'),
  express = require('express'),
  bcrypt = require('bcrypt'),
  router = express.Router(),
  SALT_WORK_FACTOR = 10;

// User Model
let userSchema = require('../Models/Users')
// CREATE User
router.route('/create-user').post((req, res, next) => {
console.log("create and unity register");
  // generate a salt
    var temp = req.body.password;
    bcrypt.genSalt(SALT_WORK_FACTOR, function(err, salt) {
      if (err) return next(err);

      // hash the password using our new salt
      bcrypt.hash(temp, salt, function(err, hash) {
          if (err) return next(err);
          // create user data with the hashed password
          userSchema.create({userId:req.body.userId, password:hash}, (error, data) => {
            console.log("request:::", req.body)
            if (error) {
              return next("error",error)
            } else {
              console.log(data)
              res.json(data)
            }
          })
      });
  });
 
});
// READ Users
router.route('/').get((req, res) => {
  userSchema.find((error, data) => {
    console.log(data);
console.log("create and unity register");

    if (error) {
      return next(error)
    } else {
      res.json(data)
    }
  })
})
// 
router.route('/login-users').post((req, res) => {
  console.log("hellow I am unity login button");
  userSchema.findOne({"userId": req.body.userId}, async (error, data) => {
    console.log("data::",req.body.userId, data)
      try{
        if(await bcrypt.compare(req.body.password, data.password)){
        // res.redirect('/')
        console.log("Password is matched")
        res.json(data)
        } else{
        console.log('Not Allowed user')
        return next(error)
        }
    } catch {
      res.status(500).send()
    }
  })
})

// Get Single User
router.route('/edit-User/:id').get((req, res) => {
  userSchema.findById(req.params.id, (error, data) => {
    if (error) {
      return next(error)
    } else {
      res.json(data)
    }
  })
})

// Update User
router.route('/update-User/:id').put((req, res, next) => {
  userSchema.findByIdAndUpdate(req.params.id, {
    $set: req.body
  }, (error, data) => {
    if (error) {
      return next(error);
      console.log(error)
    } else {
      res.json(data)
      console.log('User updated successfully !')
    }
  })
})
// Delete User
router.route('/delete-User/:id').delete((req, res, next) => {
  userSchema.findByIdAndRemove(req.params.id, (error, data) => {
    if (error) {
      return next(error);
    } else {
      res.status(200).json({
        msg: data
      })
    }
  })
})
module.exports = router;